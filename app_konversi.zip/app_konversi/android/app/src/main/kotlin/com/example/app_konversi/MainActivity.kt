package com.example.app_konversi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
